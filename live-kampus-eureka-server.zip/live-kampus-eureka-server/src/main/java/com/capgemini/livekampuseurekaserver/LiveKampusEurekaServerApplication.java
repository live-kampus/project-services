package com.capgemini.livekampuseurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveKampusEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveKampusEurekaServerApplication.class, args);
	}

}
